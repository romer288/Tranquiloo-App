import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { 
  User, Search, MessageSquare, FileText, Target, 
  Download, Edit3, Save, Plus, Trash2, CheckCircle, LogOut 
} from 'lucide-react';

// Analytics components
import AnalyticsHeader from '@/components/analytics/AnalyticsHeader';
import AnalyticsMetrics from '@/components/analytics/AnalyticsMetrics';
import AnxietyChartsSection from '@/components/analytics/AnxietyChartsSection';
import MonthlyChartsSection from '@/components/analytics/MonthlyChartsSection';
import GoalProgressSection from '@/components/analytics/GoalProgressSection';
import TriggerAnalysisTable from '@/components/analytics/TriggerAnalysisTable';
import InterventionSummariesSection from '@/components/analytics/InterventionSummariesSection';

// Chat component
import TherapistChatInterface from '@/components/therapist/TherapistChatInterface';
import TherapistReports from '@/components/therapist/TherapistReports';
import TreatmentCreation from '@/components/therapist/TreatmentCreation';
import TherapistNotifications from '@/components/therapist/TherapistNotifications';

interface PatientRecord {
  id: string;
  user_id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  patientCode: string;
  created_at: string;
}

const TherapistDashboard: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('patients');
  const [searchEmail, setSearchEmail] = useState('');
  const [searchCode, setSearchCode] = useState('');
  const [searchLoading, setSearchLoading] = useState(false);
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [patientRecords, setPatientRecords] = useState<PatientRecord[]>([]);
  const [selectedPatientData, setSelectedPatientData] = useState<any>(null);

  const handlePatientSearch = async () => {
    if (!searchEmail.trim() || !searchCode.trim()) {
      toast({
        title: "Missing Information",
        description: "Please enter both patient email and code to search",
        variant: "destructive"
      });
      return;
    }

    setSearchLoading(true);
    try {
      // Search for patient by both email AND code (as required)
      const response = await fetch(`/api/therapist/search-patient`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email: searchEmail,
          patientCode: searchCode,
          therapistId: user?.id 
        })
      });

      if (response.ok) {
        const patientData = await response.json();
        setPatientRecords([patientData]);
        toast({
          title: "Patient Found",
          description: `Found patient: ${patientData.firstName || patientData.email}`
        });
      } else {
        toast({
          title: "Patient Not Found",
          description: "No patient found with the provided email and code combination",
          variant: "destructive"
        });
        setPatientRecords([]);
      }
    } catch (error) {
      toast({
        title: "Search Error",
        description: "Failed to search for patient",
        variant: "destructive"
      });
    } finally {
      setSearchLoading(false);
    }
  };

  const handleSelectPatient = async (patientId: string) => {
    setSelectedPatientId(patientId);
    setActiveTab('analytics'); // Switch to analytics tab when patient is selected
    
    // Load patient's complete analytics data
    try {
      const response = await fetch(`/api/therapist/patient/${patientId}/analytics`);
      if (response.ok) {
        const analyticsData = await response.json();
        setSelectedPatientData(analyticsData);
      }
    } catch (error) {
      console.error('Failed to load patient analytics:', error);
    }
  };

  // Memoize handlers to prevent re-renders
  const handlePatientSearchMemo = React.useCallback(handlePatientSearch, [searchEmail, searchCode, user?.id, toast]);
  const handleSelectPatientMemo = React.useCallback(handleSelectPatient, []);



  const handleLogout = () => {
    // Redirect to logout endpoint which handles the logout flow
    window.location.href = '/api/logout';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 px-8 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Mental Therapist Portal
            </h1>
            <p className="text-gray-600">
              Welcome, Dr. {user?.username || 'Therapist'}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="default" className="bg-green-600">
              Therapist Dashboard
            </Badge>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleLogout}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
              data-testid="button-logout"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      <div className="p-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="patients" data-testid="tab-patients">Patients</TabsTrigger>
            <TabsTrigger value="notifications" data-testid="tab-notifications">Notifications</TabsTrigger>
            <TabsTrigger 
              value="analytics" 
              disabled={!selectedPatientId}
              data-testid="tab-analytics"
            >
              Analytics
            </TabsTrigger>
            <TabsTrigger 
              value="chat" 
              disabled={!selectedPatientId}
              data-testid="tab-chat"
            >
              Chat
            </TabsTrigger>
            <TabsTrigger 
              value="reports" 
              disabled={!selectedPatientId}
              data-testid="tab-reports"
            >
              Reports
            </TabsTrigger>
            <TabsTrigger 
              value="treatment" 
              disabled={!selectedPatientId}
              data-testid="tab-treatment"
            >
              Treatment Creation
            </TabsTrigger>
          </TabsList>

          <TabsContent value="patients" className="mt-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Search className="w-5 h-5" />
                    HIPAA-Compliant Patient Search
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="patient-email">Patient Email *</Label>
                      <Input
                        key="patient-email-input"
                        id="patient-email"
                        type="email"
                        value={searchEmail}
                        onChange={(e) => setSearchEmail(e.target.value)}
                        placeholder="patient@example.com"
                        data-testid="input-patient-email"
                        autoComplete="off"
                      />
                    </div>
                    <div>
                      <Label htmlFor="patient-code">Patient Code *</Label>
                      <Input
                        key="patient-code-input"
                        id="patient-code"
                        value={searchCode}
                        onChange={(e) => setSearchCode(e.target.value)}
                        placeholder="PATIENT123"
                        data-testid="input-patient-code"
                        autoComplete="off"
                      />
                    </div>
                  </div>
                  <Button 
                    onClick={handlePatientSearchMemo}
                    disabled={searchLoading}
                    className="w-full"
                    data-testid="button-search-patient"
                  >
                    {searchLoading ? 'Searching...' : 'Search Patient'}
                  </Button>
                </CardContent>
              </Card>

              {patientRecords.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Patient Records Found</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {(patientRecords ?? []).map((patient) => (
                        <div
                          key={patient.id}
                          className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                          onClick={() => handleSelectPatientMemo(patient.id)}
                          data-testid={`card-patient-${patient.id}`}
                        >
                          <div className="flex items-center gap-3">
                            <User className="w-8 h-8 text-gray-400" />
                            <div>
                              <p className="font-medium" data-testid="text-patient-name">
                                {patient.firstName && patient.lastName 
                                  ? `${patient.firstName} ${patient.lastName}`
                                  : patient.email
                                }
                              </p>
                              <p className="text-sm text-gray-600" data-testid="text-patient-email">
                                {patient.email}
                              </p>
                              <Badge variant="outline" data-testid="badge-patient-code">
                                Code: {patient.patientCode}
                              </Badge>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="notifications" className="mt-6">
            <TherapistNotifications therapistEmail={user?.email || 'therapist@example.com'} />
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            {selectedPatientData ? (
              <div className="space-y-6">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-blue-800 font-medium">
                    Viewing analytics for: {selectedPatientData.patientName || 'Patient X'}
                  </p>
                  <p className="text-blue-600 text-sm">
                    All patient data is anonymized for HIPAA compliance
                  </p>
                </div>
                
                {/* Include all patient analytics components */}
                <AnalyticsHeader
                  analysesCount={selectedPatientData.analysesCount || 0}
                  onDownloadHistory={() => {}}
                  onShareWithTherapist={() => {}}
                  onDownloadSummary={() => {}}
                />
                <AnalyticsMetrics analyses={selectedPatientData.analyses || []} />
                <AnxietyChartsSection analyses={selectedPatientData.analyses || []} />
                <MonthlyChartsSection analyses={selectedPatientData.analyses || []} />
                <GoalProgressSection goals={selectedPatientData.goals || []} />
                <TriggerAnalysisTable analyses={selectedPatientData.analyses || []} />
                <InterventionSummariesSection summaries={selectedPatientData.interventions || []} />
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-600">Please select a patient to view analytics</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="chat" className="mt-6">
            {selectedPatientId ? (
              <TherapistChatInterface 
                patientId={selectedPatientId}
                patientName={selectedPatientData?.patientName || 'Patient X'}
              />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-600">Please select a patient to start chatting</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="reports" className="mt-6">
            {selectedPatientId ? (
              <TherapistReports 
                patientId={selectedPatientId}
                patientName={selectedPatientData?.patientName || 'Patient X'}
              />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-600">Please select a patient to view reports</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="treatment" className="mt-6">
            {selectedPatientId ? (
              <TreatmentCreation 
                patientId={selectedPatientId}
                patientName={selectedPatientData?.patientName || 'Patient X'}
              />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-600">Please select a patient to create treatment plans</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default TherapistDashboard;